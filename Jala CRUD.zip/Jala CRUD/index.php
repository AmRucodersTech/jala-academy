
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>jalaCRUD</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-5">
        <h1>Student Registration</h1>
    <a class="btn btn-primary" href="create.php">Add New Student</a><br>
   
    <table class="table">
        <thead>
            <tr>
                <th>St-Id</th>
                <th>Fist Name</th>
                <th>Last Name</th>
                <th>Email</th>
                <th>Course</th>
                <th>Phone number</th>
                <th>RegDate</th>
                <th>Update/Delete</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $servername ="localhost";
            $username ="root";
           $password ="";
            $database ="classroom"; 

            $connection = new mysqli($servername, $username, $password, $database);
        //checking the connection of the database if fail
         if ($connection->connect_error) {
                die("Connection failed: " . $connection->connect_error);
                }
               // echo "Connected successfully";  
               
               $sql = "SELECT *FROM student";
               $result = $connection->query($sql);
               if(!$result){
                die("invalid query". $connection->connect_error);
               }

               while($row=$result->fetch_Assoc())
               {
                echo"
                <tr>
                <td>$row[Id]</td>
                <td>$row[fname]</td>
                <td>$row[lname]</td>
                <td>$row[email]</td>
                <td>$row[course]</td>
                <td>$row[phone]</td>
                <td>$row[regDate]</td>
                <td>
                <a class='btn btn-success btn-sm' href='/JALA/update.php?Id=$row[Id]'>Update</a>
                <a class='btn btn-danger btn-sm' href='/JALA/delete.php?Id=$row[Id]'>Delete</a>
                    
                </td>
            </tr>
                ";
               } 
            ?>
        </tbody>
    </table>

    </div>
    
</body>
</html>

