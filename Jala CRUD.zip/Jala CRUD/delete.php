<?php 
require_once "dbh.php" ;

if (isset( $_GET['Id'])) {
  $Id = $_GET['Id'];

$sql = "DELETE FROM student  WHERE Id='$Id' ";
$result = mysqli_query($conn, $sql);

if ($result) {
  
   header("location: /JALA/index.php");
   exit();
}
  else{
   die("Connection failed: " . mysqli_connect_error());
  }
}



?>
