
package callstatic;


public class CallStatic {

     private static void callMe(String text) {
        System.out.println(text);
    }

    
    public static void main(String[] args) {
        callMe("Amisi");
    }

  //  private static void callMe(String text) {
   //     System.out.println(text);
   // }
    
}
