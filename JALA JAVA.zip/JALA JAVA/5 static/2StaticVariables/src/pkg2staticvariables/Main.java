
package pkg2staticvariables;

/**
 *
 * @author AMICI
 */
public class Main {

   int age=20,Salary=30000;
    public static void main(String[] args) {
       say("Amisi");
       gender("Male");
       Main m=new Main();
        System.out.println("Age:"+m.age);
        System.out.println("Salary:" +m.Salary);
       
    }
    public static void say(String text){
        System.out.println("hello" +text);
        
    }
     public static void gender(String text){
        System.out.println("Gender is:"  +text);
    }
     
}
