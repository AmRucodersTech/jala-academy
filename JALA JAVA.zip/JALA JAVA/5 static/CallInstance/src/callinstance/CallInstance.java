/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package callinstance;

/**
 *
 * @author AMICI
 */
public class CallInstance {

    int x=6;
    
    public static void main(String[] args) {
        CallInstance c = new  CallInstance();
        // System.out.println(c.x);
    }
    
}
