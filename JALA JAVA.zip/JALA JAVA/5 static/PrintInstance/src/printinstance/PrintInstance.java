/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package printinstance;

/**
 *
 * @author AMICI
 */
public class PrintInstance {

    
     int x=6;
    public static void main(String[] args) {
        
         PrintInstance p = new  PrintInstance();
         System.out.println(p.x);
        
    }
    
}
