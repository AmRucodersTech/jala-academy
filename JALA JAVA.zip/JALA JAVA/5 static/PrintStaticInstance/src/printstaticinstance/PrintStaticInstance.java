
package printstaticinstance;
public class PrintStaticInstance {
    
   int age=20,Salary=30000;
    public static void main(String[] args) {
       say("Amisi");
       gender("Male");
      PrintStaticInstance h=new PrintStaticInstance();
        System.out.println("intance:"+ h.age);
        System.out.println("intance:" +h.Salary);
       
    }
    public static void say(String text){
        System.out.println("Static:" +text);
         
    }
    public static void gender(String text){
         System.out.println("Static:"  +text);
    }
     
     
}
