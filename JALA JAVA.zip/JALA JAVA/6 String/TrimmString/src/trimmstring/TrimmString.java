
package trimmstring;
public class TrimmString {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    String fname = "    Amisi Mwanue Sila      ";

    System.out.println(fname.trim());

  }
}
