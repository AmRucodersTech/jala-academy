
package stringequal;

/**
 *
 * @author AMICI
 */
public class StringEqual {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    String fname = "Amisi";
    String lname = "Mwnaue";
        
    // if fname and lname are equal, the result is 0
    if (fname.compareTo(lname) == 0) {

      System.out.println("Two strings are equal");
    }
    else {
      System.out.println("Two strings are not equal");
    }
  }
}
