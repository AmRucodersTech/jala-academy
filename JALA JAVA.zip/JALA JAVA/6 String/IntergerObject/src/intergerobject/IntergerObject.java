
package intergerobject;

/**
 *
 * @author AMICI
 */
public class IntergerObject {
     public static void main(String[] args) {
    Integer obj = new Integer(10);
 
    String str = obj.toString();
    System.out.println(str+":converted to String");
  }
}
