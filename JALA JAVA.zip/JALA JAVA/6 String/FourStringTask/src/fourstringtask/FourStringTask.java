
package fourstringtask;

/**
 *
 * @author AMICI
 */
public class FourStringTask {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       String fname = "Amisi";
       String lname = "Amisi";
       String pname = "Sila";
       int count;
       
       
    //equalsIgnoreCase
    System.out.println(fname.equalsIgnoreCase(lname));
    System.out.println(fname.equalsIgnoreCase(pname));
    
     // checks if "Amisi" start with "A"
    System.out.println(fname.startsWith("A"));
    
    //checks if "sila" end with "A"
    System.out.println(pname.endsWith("A"));
    
    // comparing fname with lname
    count = fname.compareTo(lname);
    System.out.println(count);
    }
    
}
