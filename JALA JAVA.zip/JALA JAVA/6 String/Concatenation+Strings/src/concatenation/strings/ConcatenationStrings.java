
package concatenation.strings;


public class ConcatenationStrings {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      // create first string
    String fname = "Amisi ";
    String lname = "Mwanue";
    

    // join two strings
    String ConString = fname.concat(lname);
    System.out.println( ConString);
  }
}