
package replacing;


public class Replacing {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     String fname = "Anisi nwnaue";

    //finding "n" and replace with "m"
    System.out.println(fname.replace('n', 'm'));

  }
}
