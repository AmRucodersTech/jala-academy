
package matchingstringregx;

public class MatchingStringRegx {
    public static void main(String[] args) {
    String regex = "^a................n$";
    System.out.println("Amisi Mwanue Sylaven".matches(regex));

  }
}