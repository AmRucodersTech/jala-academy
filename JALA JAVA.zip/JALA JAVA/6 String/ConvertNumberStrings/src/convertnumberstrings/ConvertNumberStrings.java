
package convertnumberstrings;

public class ConvertNumberStrings {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    int y = 30;
   // convert numbers to strings
    System.out.println(String.valueOf(y));
   
  }
}
