
package upperlowercase;

/**
 *
 * @author AMICI
 */
public class UpperLowerCase {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    String fname = "AMISI MWANUE SILA";
    System.out.println(fname.toUpperCase());
    System.out.println(fname.toLowerCase());
  }
}
