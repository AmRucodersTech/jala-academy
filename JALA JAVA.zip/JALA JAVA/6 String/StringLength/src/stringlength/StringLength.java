
package stringlength;

public class StringLength {

    public static void main(String[] args) {
    // create a string
    String fname = "Amisi";
    System.out.println( fname);

   
    int length = fname.length();
    System.out.println( length);
  }
}
