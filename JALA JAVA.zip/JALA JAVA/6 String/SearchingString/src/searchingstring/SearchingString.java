
package searchingstring;

/**
 *
 * @author AMICI
 */
public class SearchingString {

    public static void main(String[] args) {
    String fname = "Amisi Mwanue Sila";
    System.out.println(fname.indexOf("Mwanue"));
  }
}