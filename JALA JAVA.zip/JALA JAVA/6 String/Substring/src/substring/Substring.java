
package substring;

/**
 *
 * @author AMICI
 */
public class Substring {

    public static void main(String[] args) {
     String fname = "Amisi Mwanue Sila";

    System.out.println(fname.substring(0, 5));

  }
}