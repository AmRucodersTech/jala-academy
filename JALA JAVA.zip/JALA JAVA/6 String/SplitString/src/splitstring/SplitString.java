
package splitstring;

public class SplitString {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
   String fname = "Anisi nwnaue Sila";

    // split string from space
    String[] count =fname.split(" ");
   
    for (String str : count) {
      System.out.print(str + ", ");
    }
  }
}
