
package myname;

public class MyName {

    public static void main(String[] args) {
        String name ="Amisi Mwanue Sila";
        System.out.println(name);
    }
    
}
