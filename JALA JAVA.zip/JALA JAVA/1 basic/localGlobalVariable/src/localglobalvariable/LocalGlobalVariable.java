
package localglobalvariable;

/**
 *
 * @author AMISI MWANUE SILA
 */
public class LocalGlobalVariable {
    //Global variable
   static String name="Amisi";
    
        
    
    public static void main(String[] args) {
        System.out.println(""+name);
        // Local variable
        String name="Mwanue";
        System.out.println(name);
    }
      
  }  

