
package comment;

public class Comment {

   
    public static void main(String[] args) {
    //   System.out.println("This is a single line comment" );
    
    /*
        System.out.println("This is a multiple line comment" );
        System.out.println("This is a multiple line comment" );
        System.out.println("This is a multiple line comment" );
        System.out.println("This is a multiple line comment" );
    */
   
    System.out.println("This is a single and multiple line comment" );
    }
    
}
