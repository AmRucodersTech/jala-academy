
package variables;

/**
 *
 * @author AMISI MWANUE SILA
 */
public class Variables {
    public static void main(String[] args) {
        
           int numb1 = 4;
           float numb2 = 4.5F;
           double numb3 = 3.4;
           char c = 'F';
           boolean bool1 = false;
           boolean bool2 = true;
        System.out.println(numb1);
        System.out.println(numb2);
        System.out.println(numb3);
        System.out.println(c);
        System.out.println(bool1);
        System.out.println(bool2);
    }
    
}
