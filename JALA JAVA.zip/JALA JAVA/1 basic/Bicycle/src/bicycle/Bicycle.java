
package bicycle;

public class Bicycle {
// field of class
  int gear = 5;

  // method of class
  void braking() {
    
  }
}

// create object
Bicycle sportsBicycle = new Bicycle();

// access field and method
//sportsBicycle.gear;
//sportsBicycle.braking()
