/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package function;

/**
 *
 * @author AMICI 
 */
public class Function {
    public static void main(String[] args) {
       
      //declarering the functions
      Myname("Amisi Mwanue Sila");
    }
    // calling the function 
    public static void Myname(String text){
        System.out.println(text);
    }
}
