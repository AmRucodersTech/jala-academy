/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package even100;

/**
 *
 * @author AMICI
 */
public class Even100 {
     public static void main(String[] args) {
   // declare variables
    int i=10;

    while( i <=100){
        if(i%2 ==0)    {
            System.out.println(i);
        }    
        i++;
    }
  
  }
}