
package pkg1to20.pkgwhile;

/**
 *
 * @author AMISI MWANUE SILA 
 */
public class While {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     int a = 1, b = 20;
     while (a <= b){
         
         System.out.println(a);
       a++;
     }
    }
    
}
