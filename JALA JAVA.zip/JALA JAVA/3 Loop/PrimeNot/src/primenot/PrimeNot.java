package primenot;

/**
 *
 * @author AMICI
 */
public class PrimeNot {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    int numb =4;
    boolean check = false;
    
    
    for (int i = 2; i <= numb / 2; ++i) {
      // condition for nonprime number
      if (numb % i == 0) {
        check = true;
        break;
      }
    }

    if (!check)
      System.out.println(" Is a prime number.");
    else
      System.out.println( " Is not a prime number.");
  }
}
