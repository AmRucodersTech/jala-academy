
package printoddeven;

/**
 *
 * @author AMISI MWANUE SILA 
 */
public class PrintOddEven {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    int y[]={1,2,3,4,5,6,7,8,9}; 
    int x[]={10,11,12,13,14,15,16,17,18,19};
    // check the odd numbers
        System.out.println("Odd Numbers:");  
        for(int i=0;i<y.length;i++){  
            if(y[i]%2!=0){  
            System.out.println(y[i]);  
            }  
        }  
        
        // check the eve numbers
        System.out.println("Even Numbers:");  
        for(int i=0;i<x.length;i++){  
            if(x[i]%2==0){  
            System.out.println(x[i]);  
            }  
        }  
}
} 
