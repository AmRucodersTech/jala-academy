
package palindromenot;

/**
 *
 * @author AMICI
 */
public class PalindromeNot {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
   int Numb = 55, reversedNum = 0, remainder;
    
    // store the Numbber to originalNum
    int originalNum = Numb;
    
    // get the reverse of originalNum
    // store it in variable
    while (Numb != 0) {
      remainder = Numb % 10;
      reversedNum = reversedNum * 10 + remainder;
      Numb /= 10;
    }
    
    // check if reversedNum and originalNum are equal
    if (originalNum == reversedNum) {
      System.out.println(originalNum + " Is Palindrome.");
    }
    else {
      System.out.println(originalNum + "Is not Palindrome.");
    }
  }
}