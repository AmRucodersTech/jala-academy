/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package largernumber;

/**
 *
 * @author AMICI
 */
public class LargerNumber {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     int t[]={7,8,9}; 
   
    // check the odd numbers
        
        for(int i=0;i<t.length;i++){  
             
            System.out.println(t[2]);  
             
        }
        
        
  
}
} 
