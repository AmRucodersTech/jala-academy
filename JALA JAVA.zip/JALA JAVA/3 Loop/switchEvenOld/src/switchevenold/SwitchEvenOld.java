
package switchevenold;

/**
 *
 * @author AMICI
 */
public class SwitchEvenOld {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    int numb = 99;

    

    switch (numb % 2 ) {
    case 0:
      System.out.printf("IS  an EVEN number.\n", numb);
      break;

    case 1:
      System.out.printf("IS an ODD number.\n", numb);
      break;
    }

  }
}
