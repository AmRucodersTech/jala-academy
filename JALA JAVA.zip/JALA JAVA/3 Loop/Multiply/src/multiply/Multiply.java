
package multiply;

/**
 *
 * @author AMICI
 */
public class Multiply {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       int x=10, y=32, z=30;

        if( x >= y && x >= z)
            System.out.println(x+ "Large" );

        else if (y >= x && y >= z)
            System.out.println(y + " Large");

        else
            System.out.println(z + " Large");
    }
}
