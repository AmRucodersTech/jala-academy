
package gender;

/**
 *
 * @author AMICI
 */
public class Gender {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     String gender="Male";
     
   System.out.println("Male/Female ");
   
     
    switch(gender)
    {
        case "Male":
            System.out.println("Male");
            break;
        case "Female":
       
          System.out.println("Female");
            break;
        default:
           System.out.println("UNknown  Gender.");
    }
    System.out.println("\n");
    }
    
}
