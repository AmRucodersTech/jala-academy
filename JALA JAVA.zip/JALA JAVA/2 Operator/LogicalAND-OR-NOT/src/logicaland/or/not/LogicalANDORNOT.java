
package logicaland.or.not;

/**
 *
 * @author AMICI
 */
public class LogicalANDORNOT {
  public static void main(String[] args) {

    // && operator AND
    System.out.println((1 > 6) && (10 > 5));  
    System.out.println((6 > 3) && (40 < 2));  

    // || operator OR
    System.out.println((6 < 0) || (9 > 3));  
   

    // ! operator NOT EQUAL
    System.out.println(!(5 == 0));  
    System.out.println(!(51 > 31));  
  }
}
