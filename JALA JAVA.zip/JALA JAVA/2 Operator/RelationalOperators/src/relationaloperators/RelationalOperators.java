
package relationaloperators;

/**
 *
 * @author AMISI MWANUE SILA
 */
public class RelationalOperators {
 public static void main(String[] args) {
    
    // create variables
    int a = 20, b = 11;

    // LESS THAN
    System.out.println(a < b);
    // false is expected to be printed
    
     // LESS THAN or EQUAL TO
    System.out.println(b <= a); 
    // true is expected to be printed

     // GREATER THAN 
    System.out.println(b > a); 
    // false is expected to be printed
  
    // GREATER THAN or EQUAL TO
    System.out.println(a >= b); 
    // true is expected to be printed
  
  }
}
