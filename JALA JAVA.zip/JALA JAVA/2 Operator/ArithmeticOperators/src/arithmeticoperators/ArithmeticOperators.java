
package arithmeticoperators;

/**
 *
 * @author AMISI MWANUE SILA
 */
public class ArithmeticOperators {

    public static void main(String[] args) {
        add( 10, 2);
       sub( 10, 2);
       mult( 10, 2);
        div( 10, 2);
    }
    public static void add(int a ,int b){
        System.out.println(a+b);
    }
    public static void sub(int a ,int b){
        System.out.println(a-b);
    }
    public static void mult(int a ,int b){
        System.out.println(a*b);
    }
    public static void div(int a ,int b){
        System.out.println(a/b);
    }
}
