
package equalandnotequal;

/**
 *
 * @author AMISI MWANUE SILA
 */
public class EqualANDnotequal {

    public static void main(String[] args) {
        int x=100;
        if(x ==100 ){
             System.out.println("is Equal");
        } 
        else {
            System.out.println("is not Equal");
        }
        
    }
    
}
