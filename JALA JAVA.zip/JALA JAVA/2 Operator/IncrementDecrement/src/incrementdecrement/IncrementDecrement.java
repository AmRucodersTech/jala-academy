
package incrementdecrement;

/**
 *
 * @author AMISI MWANUE SILA
 */
public class IncrementDecrement {
    static void increament() {
        int x=4;
        x++;
        
    System.out.println(x);
  }
        static void decreament() {
        int y=4;
        y--;
        
    System.out.println(y);
  }

  public static void main(String[] args) {
    increament();
    decreament();
  }
 
}

