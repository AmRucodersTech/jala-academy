
package twonumbersequalornot;

/**
 *
 * @author AMICI
 */
public class TwoNumbersEqualOrNot {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int x=10, y=20;
        if(x == y ){
             System.out.println("is Equal");
        } 
        else {
            System.out.println("is not Equal");
        }
    }
    
}
