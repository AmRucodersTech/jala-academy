
package smallerlarger;

/**
 *
 * @author AMISI MWANUE SILA
 */
public class SmallerLarger {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int small= 20, large=25;
        
        System.out.println("Small number is:" +small);
         System.out.println("Large number is:" +large);
        
    }
    
}
